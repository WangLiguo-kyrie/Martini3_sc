#! /usr/bin/python
#manually change itp HIS to HIH(protonated HIS in original martini_v300 force field), due to preference to the model1 without spliting charge into 0.5/0.5, although HSP/HIP could be defined in force field
import sys
import os

his_count=0
with open('molecule_0_acid.itp','w') as g:
    with open('molecule_0.itp') as f:
        lines=f.readlines()
        for line in lines:
            line=line.strip('\n')
            
            #for not SC3(protonated) beads, only change resname from HIS TO HIH
            if ((' HIS ' in line)& ('SC3' not in line)):
                his_items=line
                print(his_items.replace('HIS','HIH'),file=g)
            # for HIS SC3 bead: TN5a>TQ2p, HIS>HIH, 0.0>1.0
            elif ((' HIS ' in line)& ('SC3' in line)):  
                his_items=line
                hih_items=his_items.replace('HIS','HIH').replace('TN5a','TQ2p').replace('0.0','1.0') 
                print(hih_items)
                print(hih_items,file=g)
                count+=1
            else: print(line,file=g)
print('ACid protonation change HIS number: {}'.format(his_count))
